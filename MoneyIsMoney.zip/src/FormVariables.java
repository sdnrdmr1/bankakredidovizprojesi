import javax.swing.JPanel;

public final class FormVariables {
	static JPanel CreditCalculation;
}
